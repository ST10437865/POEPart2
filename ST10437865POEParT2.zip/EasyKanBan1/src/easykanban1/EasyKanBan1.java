
package easykanban1;

import javax.swing.JOptionPane;


public class EasyKanBan1 {

    private static int taskCounter = 0; // Counter for generating task IDs
    
    public static void main(String[] args) {
   
        String name = JOptionPane.showInputDialog(null, "Enter Your Name");
        String surname = JOptionPane.showInputDialog(null, "Enter Your Surname");

        String username = JOptionPane.showInputDialog(null, "Enter Your Username");
        String password = JOptionPane.showInputDialog(null, "Enter Your Password");

        // Example of authentication logic
        if (username.equals("MM_pe") && password.equals("Shor2tb@")) {
            JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");

            // Main menu loop
            int option;
            do {
                // Display menu options
                String input = JOptionPane.showInputDialog(
                        "Choose an option:\n" +
                                "1) Add Task\n" +
                                "2) Show Report\n" +
                                "3) Quit");
                // Parse the option and handle exceptions
                option = parseIntSafely(input);
                switch (option) {
                    case 1:
                        addTask();
                        break;
                    case 2:
                        JOptionPane.showMessageDialog(null, "Show report - Coming soon");
                        break;
                    case 3:
                        JOptionPane.showMessageDialog(null, "Exiting application, Goodbye!");
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Invalid option. Please try again");
                }
            } while (option != 3);

        } else {
            JOptionPane.showMessageDialog(null, "Invalid login credentials");
        }
    }

    public static void addTask() {
        // Prompt user to enter task details
        int taskNumber = parseIntSafely(JOptionPane.showInputDialog("Enter task number:"));
        String taskName = JOptionPane.showInputDialog("Enter task name:");

        String taskDescription;
        while (true) {
            taskDescription = JOptionPane.showInputDialog("Enter task description (max 50 characters):");
            if (taskDescription.length() <= 50) {
                break;
            } else {
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
            }
        }
        String developerDetails = JOptionPane.showInputDialog("Enter developer details (First and Last name):");
        int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter task duration (in hours):"));
        String taskStatus = (String) JOptionPane.showInputDialog(null, "Select task status:",
                "Task Status", JOptionPane.QUESTION_MESSAGE, null,
                new String[]{"To Do", "Done", "Doing"}, "To Do");
        Task task = createTask(taskNumber, taskName, taskDescription, developerDetails, taskDuration, taskStatus);
        if (task != null) {
            displayTask(task);
        }
    }

    private static Task createTask(int taskNumber, String taskName, String taskDescription, String developerDetails, int taskDuration, String taskStatus) {
        Task task = new Task(taskNumber, taskName, taskDescription, developerDetails, taskDuration, taskStatus);
        return task;
    }

    private static void displayTask(Task task) {
        JOptionPane.showMessageDialog(null, task.toString());
    }

    private static int parseIntSafely(String input) {
        // Implement safe parsing of integer
        try {
            return Integer.parseInt(input);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number");
            return 0;
        }
    }
}